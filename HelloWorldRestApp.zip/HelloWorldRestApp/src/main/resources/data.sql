insert into User2 values(101, 'AB', sysdate());
insert into User2 values(101, 'sc', sysdate());
insert into User2 values(101, 'ABds', sysdate());